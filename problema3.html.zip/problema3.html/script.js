const Calcola = function() {
    let a = Number (txb1.value);
    let b =  Number (txb2.value);
    let sum = a+b;
    let diff;
    let prod;
    if (sum>=20){
        diff = a-b;
        output1.innerHTML = "La somma dei due valori inseriti è "+sum+ ".";
        output2.innerHTML = "La differenza dei due valori inseriti è "+diff+".";

    }else {
        prod = a*b;
        output1.innerHTML = "La somma dei due valori inseriti è "+sum+ ".";
        output2.innerHTML = "Il prodotto dei due valori inseriti è "+prod+".";

    };
};
btnCalcolo.addEventListener ("click", Calcola)